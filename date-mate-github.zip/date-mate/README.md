# 데이트메이트 (DATE MATE) — 단일 파일 AI 데이트 플래너

프레임워크(React, Vue, Vite 등), `npm`, `package.json`, 빌드 과정 없이 **`index.html` 단일 파일**만으로 동작하는 맞춤형 데이트 코스 플래너입니다.

## 특징

- **Zero-Framework & Zero-Build**: 순수 HTML5 + CSS3 + Vanilla JavaScript로 작성되어 별도 설치나 빌드 없이 즉시 실행됩니다.
- **로컬 바로 실행**: `index.html` 파일을 브라우저로 더블 클릭(`file://`)해도 모든 기능이 정상 동작합니다.
- **즉시 Vercel 배포**: GitHub 저장소에 그대로 업로드한 뒤 Vercel에서 Import 하면 별도 빌드 설정 없이 바로 배포됩니다.

## Vercel 배포 방법

1. 이 저장소를 GitHub에 업로드합니다.
2. [Vercel](https://vercel.com) 대시보드에서 **Add New Project**를 클릭하고 GitHub 저장소를 선택합니다.
3. Build Command / Output Directory 설정 없이 **Deploy** 버튼을 누르면 즉시 배포가 완료됩니다.